# Systematic Quantization of Vision Models based on MLPs

This folder contains the core codes for the implementation of `Systematic Quantization of Vision Models based on MLPs`. 



## Training

To train the model(s) in the paper, run this command:

```shell
python -m torch.distributed.launch --nproc_per_node 8 train.py -c XXX.yaml [data_root]
```

>YAML file should include specified training hyperparameters
>
>data_root should specified the root for Imagenet dataset



## Evaluation

To evaluate my model on ImageNet, run:

```shell
python validate.py --model q_convMixer_768_32 --b 128 --num_classes 1000 [data_root]
```

>data_root should specified the root for Imagenet dataset
>
>all registered quantization models are provided in q_mlp.py and q_convmixer.py



## Extra Notes

Due to file size limits for the supplementary material, we only include the modified files that are different from the timm framework in the zip. All provided files and folders should be placed under *timm/models/* folder. The complete code will be released once the paper is accepted.


import torch
import cv2
import numpy as np
from typing import Tuple, List, Dict

# reuse read / write / plot image methods
from retinanet_utils import show_images_sequence


''' IMAGE READ / WRITE '''
def read_image(fname: str, shape: Tuple[int, int] = (320, 320)):
    img = cv2.imread(fname)
    h, w, _ = img.shape
    dims = (w, h)

    img = cv2.resize(img, shape)
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

    return img, dims


def save_image(fname: str, image: np.array, dims: Tuple[int, int]):
    img = cv2.resize(image.astype('uint8'), dims)
    img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
    cv2.imwrite(fname, img)
    


''' 
    IMAGE TO / FROM TENSOR
'''
mean = np.array([[[0.485, 0.456, 0.406]]])
std = np.array([[[0.229, 0.224, 0.225]]])

def image_to_tensor(image):
    image = ((image.astype(np.float32) / 255.) - mean) / std
    image = image.transpose((2,0,1))
    image = torch.FloatTensor(image).cuda().unsqueeze(0)
    return image

def image_to_numpy(image):
    image = image.cpu().squeeze(0).numpy()
    image = image.transpose((1,2,0)) * std + mean
    image = np.clip(image, 0, 1)
    return (image * 255.).astype(int)
    


''' 
    ANNOTATIONS and PLOTTING 
'''
coco_classes = ["background", "person", "bicycle", "car", "motorcycle", "airplane", "bus", "train", "truck", "boat", "traffic light", "fire hydrant", "stop sign", "parking meter", "bench", "bird", "cat", "dog", "horse", "sheep", "cow", "elephant", "bear", "zebra", "giraffe", "backpack", "umbrella", "handbag", "tie", "suitcase", "frisbee", "skis", "snowboard", "sports ball", "kite", "baseball bat", "baseball glove", "skateboard", "surfboard", "tennis racket", "bottle", "wine glass", "cup", "fork", "knife", "spoon", "bowl", "banana", "apple", "sandwich", "orange", "broccoli", "carrot", "hot dog", "pizza", "donut", "cake", "chair", "couch", "potted plant", "bed", "dining table", "toilet", "tv", "laptop", "mouse", "remote", "keyboard", "cell phone","microwave", "oven", "toaster", "sink", "refrigerator", "book", "clock", "vase", "scissors", "teddy bear", "hair drier", "toothbrush"]
# label_to_class_idx = {0: 1, 1: 2, 2: 3, 3: 4, 4: 5, 5: 6, 6: 7, 7: 8, 8: 9, 9: 10, 10: 11, 11: 13, 12: 14, 13: 15, 14: 16, 15: 17, 16: 18, 17: 19, 18: 20, 19: 21, 20: 22, 21: 23, 22: 24, 23: 25, 24: 27, 25: 28, 26: 31, 27: 32, 28: 33, 29: 34, 30: 35, 31: 36, 32: 37, 33: 38, 34: 39, 35: 40, 36: 41, 37: 42, 38: 43, 39: 44, 40: 46, 41: 47, 42: 48, 43: 49, 44: 50, 45: 51, 46: 52, 47: 53, 48: 54, 49: 55, 50: 56, 51: 57, 52: 58, 53: 59, 54: 60, 55: 61, 56: 62, 57: 63, 58: 64, 59: 65, 60: 67, 61: 70, 62: 72, 63: 73, 64: 74, 65: 75, 66: 76, 67: 77, 68: 78, 69: 79, 70: 80, 71: 81, 72: 82, 73: 84, 74: 85, 75: 86, 76: 87, 77: 88, 78: 89, 79: 90}
COLORS = np.random.uniform(0, 255, size=(len(coco_classes), 3))


def draw_boxes(boxes, labels, scores, image):
    for (label, confidence, bbox) in zip(labels, scores, boxes):
        color = COLORS[label]
        class_name = coco_classes[label]
        text = f'{class_name} {confidence*100:.0f}%'

        top_left = (int(bbox[0]), int(bbox[1]))
        bottom_right = (int(bbox[2]), int(bbox[3]))
        thickness = 2

        cv2.rectangle(image, top_left, bottom_right, color, thickness)
        cv2.putText(image, text, (top_left[0], top_left[1]-5),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2, 
                    lineType=cv2.LINE_AA)
    
    return image


def annotate_image(image: np.array, model: torch.nn.Module, encoder, confidence: float = 0.8):
    # get predictions
    with torch.no_grad():
        locs, probs = model(image_to_tensor(image))

    results = encoder.decode_batch(locs, probs, nms_threshold=confidence)[0]
    bboxes, labels, scores = [r.detach().cpu().numpy() for r in results]

    # filter out only confident results
    filter = scores > confidence
    scores = scores[filter]
    labels = labels[filter]
    bboxes = bboxes[filter] * 300

    annotated_image = draw_boxes(bboxes, labels, scores, image.copy())

    return annotated_image



''' FIFTYONE '''
import fiftyone as fo


# def detections_fiftyone_format(fname: str, model, encoder, nms: float = 0.45):
#     detections = []
#     image, _ = read_image(fname, shape=(300,300))
    
#     # get predictions
#     with torch.no_grad():
#         locs, probs = model(image_to_tensor(image))

#     results = encoder.decode_batch(locs, probs, nms_threshold=nms)[0]
#     bboxes, labels, scores = [r.detach().cpu().numpy() for r in results]

#     # no detections found
#     if len(bboxes) == 0:
#         return fo.Detections(detections=detections)

#     bboxes[:, 2] -= bboxes[:, 0]
#     bboxes[:, 3] -= bboxes[:, 1]

#     # build detections list
#     for label, score, bbox in zip(labels, scores, bboxes):
#         detection = fo.Detection(label=coco_classes[label], bounding_box=bbox.tolist(), confidence=score)
#         detections.append(detection)
    
#     return fo.Detections(detections=detections)

coco_classes = ["background", "person", "bicycle", "car", "motorcycle", "airplane", "bus", "train", "truck", "boat", "traffic light", "fire hydrant", "stop sign", "parking meter", "bench", "bird", "cat", "dog", "horse", "sheep", "cow", "elephant", "bear", "zebra", "giraffe", "backpack", "umbrella", "handbag", "tie", "suitcase", "frisbee", "skis", "snowboard", "sports ball", "kite", "baseball bat", "baseball glove", "skateboard", "surfboard", "tennis racket", "bottle", "wine glass", "cup", "fork", "knife", "spoon", "bowl", "banana", "apple", "sandwich", "orange", "broccoli", "carrot", "hot dog", "pizza", "donut", "cake", "chair", "couch", "potted plant", "bed", "dining table", "toilet", "tv", "laptop", "mouse", "remote", "keyboard", "cell phone","microwave", "oven", "toaster", "sink", "refrigerator", "book", "clock", "vase", "scissors", "teddy bear", "hair drier", "toothbrush"]
pascal_classes = {0: 'background', 1: 'person', 2: 'bicycle', 3: 'car', 4: 'motorbike', 5: 'aeroplane', 6: 'bus', 7: 'train', 9: 'boat', 16: 'bird', 17: 'cat', 18: 'dog', 19: 'horse', 20: 'sheep', 21: 'cow', 44: 'bottle', 62: 'chair', 63: 'sofa', 64: 'pottedplant', 67: 'diningtable', 72: 'tvmonitor', 73: 'tvmonitor'}
coco_to_pascal = {'motorcycle': 'motorbike', 'airplane': 'aeroplane', 'couch': 'sofa', 'potted plant': 'pottedplant', 'dining table': 'diningtable', 'tv': 'tvmonitor', 'laptop': 'tvmonitor'}


def detections_fiftyone_format(fname: str, model, encoder, nms: float = 0.45, dataset: str = 'coco'):
    detections = []
    image, _ = read_image(fname, shape=(300,300))

    # get predictions
    with torch.no_grad():
        locs, probs = model(image_to_tensor(image))

    results = encoder.decode_batch(locs, probs, nms_threshold=nms)[0]
    bboxes, labels, scores = [r.detach().cpu().numpy() for r in results]

    # no detections found
    if len(bboxes) == 0:
        return fo.Detections(detections=detections)

    bboxes[:, 2] -= bboxes[:, 0]
    bboxes[:, 3] -= bboxes[:, 1]

    # build detections list
    for label, score, bbox in zip(labels, scores, bboxes):
        label_name = coco_classes[label]

        # convert classes to pascal if necessary and skip if not in list
        if dataset == 'pascal':
            if label_name in coco_to_pascal:
                label_name = coco_to_pascal[label_name]
            if label_name not in pascal_classes.values():
                continue
        
        detection = fo.Detection(label=label_name, bounding_box=bbox.tolist(), confidence=score)
        detections.append(detection)
    
    return fo.Detections(detections=detections)


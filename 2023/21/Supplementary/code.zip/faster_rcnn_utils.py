import torch, cv2
import numpy as np
import fiftyone as fo
from typing import Tuple, List, Dict



''' IMAGE READ / WRITE '''
def read_image(fname: str):
    img = cv2.imread(fname)
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    return img


def save_image(fname: str, image: np.array):
    image = cv2.cvtColor(image.astype('uint8'), cv2.COLOR_RGB2BGR)
    cv2.imwrite(fname, image)
    


''' IMAGE TO / FROM TENSOR '''
def image_to_tensor(image):
    image = image.transpose((2,0,1))
    image = torch.FloatTensor(image).cuda().unsqueeze(0) / 255.
    return image


def image_to_numpy(image):
    image = image.cpu().squeeze(0).numpy()
    image = image.transpose((1,2,0))
    image = np.clip(image, 0, 1)
    return (image * 255.).astype(int)



''' FIFTYONE '''
# classes = ['0', 'person', 'bicycle', 'car', 'motorcycle', 'airplane', 'bus', 'train', 'truck', 'boat', 'traffic light', 'fire hydrant', '12', 'stop sign', 'parking meter', 'bench', 'bird', 'cat', 'dog', 'horse', 'sheep', 'cow', 'elephant', 'bear', 'zebra', 'giraffe', '26', 'backpack', 'umbrella', '29', '30', 'handbag', 'tie', 'suitcase', 'frisbee', 'skis', 'snowboard', 'sports ball', 'kite', 'baseball bat', 'baseball glove', 'skateboard', 'surfboard', 'tennis racket', 'bottle', '45', 'wine glass', 'cup', 'fork', 'knife', 'spoon', 'bowl', 'banana', 'apple', 'sandwich', 'orange', 'broccoli', 'carrot', 'hot dog', 'pizza', 'donut', 'cake', 'chair', 'couch', 'potted plant', 'bed', '66', 'dining table', '68', '69', 'toilet', '71', 'tv', 'laptop', 'mouse', 'remote', 'keyboard', 'cell phone', 'microwave', 'oven', 'toaster', 'sink', 'refrigerator', '83', 'book', 'clock', 'vase', 'scissors', 'teddy bear', 'hair drier', 'toothbrush']
coco_classes = {0: '0', 1: 'person', 2: 'bicycle', 3: 'car', 4: 'motorcycle', 5: 'airplane', 6: 'bus', 7: 'train', 8: 'truck', 9: 'boat', 10: 'traffic light', 11: 'fire hydrant', 12: '12', 13: 'stop sign', 14: 'parking meter', 15: 'bench', 16: 'bird', 17: 'cat', 18: 'dog', 19: 'horse', 20: 'sheep', 21: 'cow', 22: 'elephant', 23: 'bear', 24: 'zebra', 25: 'giraffe', 26: '26', 27: 'backpack', 28: 'umbrella', 29: '29', 30: '30', 31: 'handbag', 32: 'tie', 33: 'suitcase', 34: 'frisbee', 35: 'skis', 36: 'snowboard', 37: 'sports ball', 38: 'kite', 39: 'baseball bat', 40: 'baseball glove', 41: 'skateboard', 42: 'surfboard', 43: 'tennis racket', 44: 'bottle', 45: '45', 46: 'wine glass', 47: 'cup', 48: 'fork', 49: 'knife', 50: 'spoon', 51: 'bowl', 52: 'banana', 53: 'apple', 54: 'sandwich', 55: 'orange', 56: 'broccoli', 57: 'carrot', 58: 'hot dog', 59: 'pizza', 60: 'donut', 61: 'cake', 62: 'chair', 63: 'couch', 64: 'potted plant', 65: 'bed', 66: '66', 67: 'dining table', 68: '68', 69: '69', 70: 'toilet', 71: '71', 72: 'tv', 73: 'laptop', 74: 'mouse', 75: 'remote', 76: 'keyboard', 77: 'cell phone', 78: 'microwave', 79: 'oven', 80: 'toaster', 81: 'sink', 82: 'refrigerator', 83: '83', 84: 'book', 85: 'clock', 86: 'vase', 87: 'scissors', 88: 'teddy bear', 89: 'hair drier', 90: 'toothbrush'}
pascal_classes = {0: 'background', 1: 'person', 2: 'bicycle', 3: 'car', 4: 'motorbike', 5: 'aeroplane', 6: 'bus', 7: 'train', 9: 'boat', 16: 'bird', 17: 'cat', 18: 'dog', 19: 'horse', 20: 'sheep', 21: 'cow', 44: 'bottle', 62: 'chair', 63: 'sofa', 64: 'pottedplant', 67: 'diningtable', 72: 'tvmonitor', 73: 'tvmonitor'}


# def detections_fiftyone_format(fname: str, model):
#     detections = []

#     with torch.no_grad():
#         image = read_image(fname)
#         out = model(image_to_tensor(image))[0]

#         labels = out['labels'].cpu().numpy()
#         scores = out['scores'].cpu().numpy()
#         bboxes = out['boxes' ].cpu().numpy()

#         if len(scores) == 0:
#             return fo.Detections(detections=[])
            
#         # absolute to relative dimensions
#         bboxes[:, [0,2]] /= (image.shape[1])
#         bboxes[:, [1,3]] /= (image.shape[0])

#         # convert bounding boxes to fiftyone format
#         # [x1, y1, x2, y2] --> [x, y, w, h]
#         bboxes[:, 2] = bboxes[:, 2] - bboxes[:, 0]
#         bboxes[:, 3] = bboxes[:, 3] - bboxes[:, 1]

#         # build detections list
#         for label, score, bbox in zip(labels, scores, bboxes):
#             detection = fo.Detection(label=coco_classes[label], bounding_box=bbox.tolist(), confidence=score)
#             detections.append(detection)
    
#     return fo.Detections(detections=detections)


def detections_fiftyone_format(fname: str, model, dataset: str = 'coco'):
    detections = []

    if dataset == 'coco':
        classes = coco_classes
        # get_idx = lambda label : label_to_class_idx[int(label)]

    elif dataset == 'pascal':
        classes = pascal_classes
        # get_idx = lambda label : int(label) + 1

    else:
        raise Exception(f'dataset {dataset} not recognized')


    with torch.no_grad():
        image = read_image(fname)
        out = model(image_to_tensor(image))[0]

        labels = out['labels'].cpu().numpy()
        scores = out['scores'].cpu().numpy()
        bboxes = out['boxes' ].cpu().numpy()

        if len(scores) == 0:
            return fo.Detections(detections=[])
            
        # absolute to relative dimensions
        bboxes[:, [0,2]] /= (image.shape[1])
        bboxes[:, [1,3]] /= (image.shape[0])

        # convert bounding boxes to fiftyone format
        # [x1, y1, x2, y2] --> [x, y, w, h]
        bboxes[:, 2] = bboxes[:, 2] - bboxes[:, 0]
        bboxes[:, 3] = bboxes[:, 3] - bboxes[:, 1]

        # build detections list
        for label, score, bbox in zip(labels, scores, bboxes):
            if label in classes:
                detection = fo.Detection(label=classes[label], bounding_box=bbox.tolist(), confidence=float(score))
                detections.append(detection)
    
    return fo.Detections(detections=detections)






''' 
    ANNOTATIONS and PLOTTING 
'''
from retinanet_utils import show_images_sequence
COLORS = np.random.uniform(0, 255, size=(len(coco_classes), 3))


def draw_boxes(boxes, labels, scores, image):
    for (label, confidence, bbox) in zip(labels, scores, boxes):
        color = COLORS[label]
        class_name = coco_classes[label]
        text = f'{class_name} {confidence*100:.0f}%'

        top_left = (int(bbox[0]), int(bbox[1]))
        bottom_right = (int(bbox[2]), int(bbox[3]))
        thickness = 2

        cv2.rectangle(image, top_left, bottom_right, color, thickness)
        cv2.putText(image, text, (top_left[0], top_left[1]-5),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2, 
                    lineType=cv2.LINE_AA)
    
    return image

def annotate_image(image: np.array, model: torch.nn.Module, confidence: float = 0.8):
    # get predictions
    with torch.no_grad():
        out = model(image_to_tensor(image))[0]

    labels = out['labels'].cpu().numpy()
    scores = out['scores'].cpu().numpy()
    bboxes = out['boxes' ].cpu().numpy()

    # filter out only confident results
    filter = scores > confidence
    scores = scores[filter]
    labels = labels[filter]
    bboxes = bboxes[filter]

    annotated_image = draw_boxes(bboxes, labels, scores, image.copy())
    return annotated_image
import torch, json, cv2
import numpy as np
import fiftyone as fo

from typing import Tuple, List, Dict
from matplotlib import pyplot as plt
from tqdm.notebook import trange
from pycocotools.cocoeval import COCOeval



''' IMAGE READ / WRITE '''
def read_image(fname: str, shape: Tuple[int, int] = (320, 320), min_side=608, max_side=1024):
    img = cv2.imread(fname)
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    h, w, _ = img.shape

    small_side = min(h, w)
    large_side = max(h, w)

    actual_scale = large_side / small_side
    target_scale = max_side / min_side

    # check if the largest side is now greater than max_side, which can happen
    # when images have a large aspect ratio
    if actual_scale > target_scale:
        scale = max_side / large_side
    else:
        scale = min_side / small_side

    # resize the image with the computed scale
    img = cv2.resize(img, (int(round(w * scale)), int(round(h * scale))))
    h1, w1, _ = img.shape

    pad_h = 32 - h1 % 32
    pad_w = 32 - w1 % 32

    new_image = np.zeros((h1 + pad_h, w1 + pad_w, 3)).astype(np.uint8)
    new_image[:h1, :w1, :] = img

    return new_image, (h, w, pad_h, pad_w)


def save_image(fname: str, image: np.array, resize_data: Tuple[int]):
    h, w, pad_h, pad_w = resize_data
    image = image[:-pad_h, :-pad_w]
    image = cv2.resize(image.astype('uint8'), (w, h))
    image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
    cv2.imwrite(fname, image)
    


''' 
    IMAGE TO / FROM TENSOR
'''
mean = np.array([[[0.485, 0.456, 0.406]]])
std = np.array([[[0.229, 0.224, 0.225]]])

def image_to_tensor(image):
    image = ((image.astype(np.float32) / 255.) - mean) / std
    image = image.transpose((2,0,1))
    image = torch.FloatTensor(image).cuda().unsqueeze(0)
    return image

def image_to_numpy(image):
    image = image.cpu().squeeze(0).numpy()
    image = image.transpose((1,2,0)) * std + mean
    image = np.clip(image, 0, 1)
    return (image * 255.).astype(int)




''' PyCOCOTools '''
def evaluate_coco(dataset, model, threshold=0.05): 
    results = []

    with torch.no_grad():
        for i in trange(len(dataset)):
            data = dataset[i]
            scale = data['scale']

            # filter results
            scores, labels, bboxes = model(data['img'].permute(2,0,1).cuda().float().unsqueeze(0))
            filter = scores > threshold
            scores, labels, bboxes = scores[filter].cpu(), labels[filter].cpu(), bboxes[filter].cpu() / scale

            if len(bboxes) > 0:
                # convert bounding boxes to COCO format [x1, y1, x2, y2] --> [x, y, w, h]
                bboxes[:, 2] -= bboxes[:, 0]
                bboxes[:, 3] -= bboxes[:, 1]

                for label, score, bbox in zip(labels, scores, bboxes):
                    image_result = {
                        'image_id'    : dataset.image_ids[i],
                        'category_id' : dataset.label_to_coco_label(int(label)),
                        'score'       : float(score),
                        'bbox'        : bbox.tolist(),
                    }
                    results.append(image_result)

        # load results in COCO evaluation tool
        coco_true = dataset.coco
        json.dump(results, open('temp.json', 'w'), indent=4)
        coco_pred = coco_true.loadRes('temp.json')

        # run COCO evaluation
        coco_eval = COCOeval(coco_true, coco_pred, 'bbox')
        coco_eval.params.imgIds = dataset.image_ids
        coco_eval.evaluate()
        coco_eval.accumulate()
        coco_eval.summarize()



''' FIFTYONE '''
'''
dataset = load_coco_dataset_in_fiftyone('data/coco')

for sample in tqdm(dataset):
    detections = detections_fiftyone_format(sample.filepath, retinanet)
    sample['prediction'] = detections
    sample.save()

results = dataset_small.evaluate_detections('prediction', gt_field='detections', eval_key='eval', compute_mAP=True,)
print(f'mAP: {results.mAP():.3f}')
'''
pascal_classes = {0: 'background', 1: 'person', 2: 'bicycle', 3: 'car', 4: 'motorbike', 5: 'aeroplane', 6: 'bus', 7: 'train', 9: 'boat', 15: 'bird', 16: 'cat', 17: 'dog', 18: 'horse', 19: 'sheep', 20: 'cow', 40: 'bottle', 57: 'chair', 58: 'sofa', 59: 'pottedplant', 61: 'diningtable', 63: 'tvmonitor'}
coco_classes = {0: 'background', 1: 'person', 2: 'bicycle', 3: 'car', 4: 'motorcycle', 5: 'airplane', 6: 'bus', 7: 'train', 8: 'truck', 9: 'boat', 10: 'traffic light', 11: 'fire hydrant', 13: 'stop sign', 14: 'parking meter', 15: 'bench', 16: 'bird', 17: 'cat', 18: 'dog', 19: 'horse', 20: 'sheep', 21: 'cow', 22: 'elephant', 23: 'bear', 24: 'zebra', 25: 'giraffe', 27: 'backpack', 28: 'umbrella', 31: 'handbag', 32: 'tie', 33: 'suitcase', 34: 'frisbee', 35: 'skis', 36: 'snowboard', 37: 'sports ball', 38: 'kite', 39: 'baseball bat', 40: 'baseball glove', 41: 'skateboard', 42: 'surfboard', 43: 'tennis racket', 44: 'bottle', 46: 'wine glass', 47: 'cup', 48: 'fork', 49: 'knife', 50: 'spoon', 51: 'bowl', 52: 'banana', 53: 'apple', 54: 'sandwich', 55: 'orange', 56: 'broccoli', 57: 'carrot', 58: 'hot dog', 59: 'pizza', 60: 'donut', 61: 'cake', 62: 'chair', 63: 'couch', 64: 'potted plant', 65: 'bed', 67: 'dining table', 70: 'toilet', 72: 'tv', 73: 'laptop', 74: 'mouse', 75: 'remote', 76: 'keyboard', 77: 'cell phone', 78: 'microwave', 79: 'oven', 80: 'toaster', 81: 'sink', 82: 'refrigerator', 84: 'book', 85: 'clock', 86: 'vase', 87: 'scissors', 88: 'teddy bear', 89: 'hair drier', 90: 'toothbrush', 12: 'N/A', 26: 'N/A', 29: 'N/A', 30: 'N/A', 45: 'N/A', 66: 'N/A', 68: 'N/A', 69: 'N/A', 71: 'N/A', 83: 'N/A'}
label_to_class_idx = {0: 1, 1: 2, 2: 3, 3: 4, 4: 5, 5: 6, 6: 7, 7: 8, 8: 9, 9: 10, 10: 11, 11: 13, 12: 14, 13: 15, 14: 16, 15: 17, 16: 18, 17: 19, 18: 20, 19: 21, 20: 22, 21: 23, 22: 24, 23: 25, 24: 27, 25: 28, 26: 31, 27: 32, 28: 33, 29: 34, 30: 35, 31: 36, 32: 37, 33: 38, 34: 39, 35: 40, 36: 41, 37: 42, 38: 43, 39: 44, 40: 46, 41: 47, 42: 48, 43: 49, 44: 50, 45: 51, 46: 52, 47: 53, 48: 54, 49: 55, 50: 56, 51: 57, 52: 58, 53: 59, 54: 60, 55: 61, 56: 62, 57: 63, 58: 64, 59: 65, 60: 67, 61: 70, 62: 72, 63: 73, 64: 74, 65: 75, 66: 76, 67: 77, 68: 78, 69: 79, 70: 80, 71: 81, 72: 82, 73: 84, 74: 85, 75: 86, 76: 87, 77: 88, 78: 89, 79: 90}


def detections_fiftyone_format(fname: str, model, dataset: str = 'coco'):
    detections = []

    if dataset == 'coco':
        classes = coco_classes
        get_idx = lambda label : label_to_class_idx[int(label)]

    elif dataset == 'pascal':
        classes = pascal_classes
        get_idx = lambda label : int(label) + 1

    else:
        raise Exception(f'dataset {dataset} not recognized')


    with torch.no_grad():
        image, (h, w, pad_h, pad_w) = read_image(fname)
        out = model(image_to_tensor(image))

        scores = out[0].cpu().numpy()
        labels = out[1].cpu().numpy()
        bboxes = out[2].cpu().numpy()

        if len(scores) == 0:
            return fo.Detections(detections=[])
            
        # absolute to relative dimensions
        bboxes[:, [0,2]] /= (image.shape[1] - pad_w)
        bboxes[:, [1,3]] /= (image.shape[0] - pad_h)

        # convert bounding boxes to fiftyone format
        # [x1, y1, x2, y2] --> [x, y, w, h]
        bboxes[:, 2] = bboxes[:, 2] - bboxes[:, 0]
        bboxes[:, 3] = bboxes[:, 3] - bboxes[:, 1]

        # build detections list
        for label, score, bbox in zip(labels, scores, bboxes):
            class_idx = get_idx(label)

            if class_idx in classes:
                detection = fo.Detection(label=classes[class_idx], bounding_box=bbox.tolist(), confidence=float(score))
                detections.append(detection)
    
    return fo.Detections(detections=detections)




''' 
    ANNOTATIONS and PLOTTING 
'''
COLORS = np.random.uniform(0, 255, size=(len(coco_classes), 3))


def draw_boxes(boxes, labels, scores, image):
    for (label, confidence, bbox) in zip(labels, scores, boxes):
        color = COLORS[label]
        class_name = coco_classes[label_to_class_idx[label]]
        text = f'{class_name} {confidence*100:.0f}%'

        top_left = (int(bbox[0]), int(bbox[1]))
        bottom_right = (int(bbox[2]), int(bbox[3]))
        thickness = 2

        cv2.rectangle(image, top_left, bottom_right, color, thickness)
        cv2.putText(image, text, (top_left[0], top_left[1]-5),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2, 
                    lineType=cv2.LINE_AA)
    
    return image


def annotate_image(image: np.array, model: torch.nn.Module, confidence: float = 0.8):
    # get predictions
    with torch.no_grad():
        out = model(image_to_tensor(image))
        
    scores = out[0].cpu().numpy()
    labels = out[1].cpu().numpy()
    bboxes = out[2].cpu().numpy()

    # filter out only confident results
    filter = scores > confidence
    scores = scores[filter]
    labels = labels[filter]
    bboxes = bboxes[filter]

    annotated_image = draw_boxes(bboxes, labels, scores, image.copy())

    # del tensor_image, out, filter, scores, labels, bboxes
    return annotated_image


def show_images_sequence(originals: List[np.ndarray], cloaks: List[np.ndarray], diffs: List[np.ndarray], nrows: int, ncols: int):
    img_size = 3
    fig, axs = plt.subplots(nrows * 3, ncols, figsize=(ncols*img_size, nrows*3*img_size))

    for row in range(0, nrows*3, 3):
        for col in range(ncols):
            sample_no = (row // 3) * ncols + col
            ax_orig = axs[row + 0, col]
            ax_clkd = axs[row + 1, col]
            ax_diff = axs[row + 2, col]
            
            orig = originals[sample_no].astype(int)
            clkd = cloaks[sample_no].astype(int)
            diff = (diffs[sample_no]).astype(int)

            ax_orig.imshow(orig, vmin=0, vmax=255)
            ax_clkd.imshow(clkd, vmin=0, vmax=255)
            ax_diff.imshow(diff, vmin=0, vmax=255)

            for ax in [ax_orig, ax_clkd, ax_diff]:
                ax.axis(False)
                    
    plt.tight_layout()
    plt.show()
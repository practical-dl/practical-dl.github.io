import sys
import matplotlib

matplotlib.use("Agg")
sys.path.insert(0, "lib")
